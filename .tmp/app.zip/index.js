import { default as concatString_1_0 } from './functions/concat-string/1.0';
import { default as datePreset_1_0 } from './functions/date-preset/1.0';
import { default as expression_1_0 } from './functions/expression/1.0';
import { default as generateWordDocument_1_0 } from './functions/generate-word-document/1.0';
import { default as getCurrentUser_1_0 } from './functions/get-current-user/1.0';
import { default as sendEmail_1_0 } from './functions/send-email/1.0';

const fn = {
  "concatString 1.0": concatString_1_0,
  "datePreset 1.0": datePreset_1_0,
  "expression 1.0": expression_1_0,
  "generateWordDocument 1.0": generateWordDocument_1_0,
  "getCurrentUser 1.0": getCurrentUser_1_0,
  "sendEmail 1.0": sendEmail_1_0,
};

export default fn;
