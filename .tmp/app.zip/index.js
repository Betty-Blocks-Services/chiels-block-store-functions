import { default as concatString_1_0 } from './concat-string/1.0';
import { default as datePreset_1_0 } from './date-preset/1.0';
import { default as getCurrentUser_1_0 } from './get-current-user/1.0';

const fn = {
  "concatString 1.0": concatString_1_0,
  "datePreset 1.0": datePreset_1_0,
  "getCurrentUser 1.0": getCurrentUser_1_0,
};

export default fn;
