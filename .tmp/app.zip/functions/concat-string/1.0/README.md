# concatString

Concatenates two strings with an optional separator to combine two values into one string (eg, fullname is firstname + space + lastname)
