# generate word document

Generates a word document based on the used template docx file
